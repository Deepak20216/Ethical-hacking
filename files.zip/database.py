"""SQLite helpers: connection handling, schema creation, audit logging, demo data."""
import os
import sqlite3
from flask import current_app, g, request, session
from werkzeug.security import generate_password_hash

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    email TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('admin','user')),
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS assets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    target TEXT NOT NULL,                 -- URL (web) or IP/hostname (host)
    asset_type TEXT NOT NULL CHECK (asset_type IN ('web','host')),
    importance TEXT NOT NULL DEFAULT 'Medium'
        CHECK (importance IN ('Low','Medium','High','Critical')),
    description TEXT,
    authorized INTEGER NOT NULL DEFAULT 0,  -- user must confirm authorization
    created_by INTEGER REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS assessments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    asset_id INTEGER NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
    assessment_type TEXT NOT NULL DEFAULT 'HTTP Header Check',
    status TEXT NOT NULL,                 -- Completed / Failed
    summary TEXT,
    run_by INTEGER REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS vulnerabilities (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    asset_id INTEGER NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
    assessment_id INTEGER REFERENCES assessments(id) ON DELETE SET NULL,
    check_key TEXT,                       -- e.g. 'content-security-policy' (used for re-verification)
    title TEXT NOT NULL,
    description TEXT,
    severity TEXT NOT NULL CHECK (severity IN ('Low','Medium','High','Critical')),
    status TEXT NOT NULL DEFAULT 'Open'
        CHECK (status IN ('Open','In Progress','Resolved','Accepted Risk')),
    recommendation TEXT,
    evidence TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS port_scans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    asset_id INTEGER NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
    ports_scanned TEXT NOT NULL,
    open_count INTEGER NOT NULL DEFAULT 0,
    closed_count INTEGER NOT NULL DEFAULT 0,
    unknown_count INTEGER NOT NULL DEFAULT 0,
    run_by INTEGER REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS port_scan_results (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    scan_id INTEGER NOT NULL REFERENCES port_scans(id) ON DELETE CASCADE,
    port INTEGER NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('Open','Closed','Unknown')),
    service_guess TEXT,                   -- from port-number mapping only (NOT verified)
    risk_level TEXT CHECK (risk_level IN ('Low','Medium','High','Critical')),
    risk_score INTEGER,
    rationale TEXT,                       -- transparent explanation of the score
    recommendation TEXT
);

CREATE TABLE IF NOT EXISTS disclosures (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    reference TEXT NOT NULL UNIQUE,       -- e.g. VT-2026-0001
    reporter_name TEXT NOT NULL,
    reporter_email TEXT NOT NULL,
    asset_id INTEGER REFERENCES assets(id) ON DELETE SET NULL,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    evidence_summary TEXT,
    status TEXT NOT NULL DEFAULT 'Submitted'
        CHECK (status IN ('Submitted','Under Review','Accepted','Rejected','Closed')),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS disclosure_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    disclosure_id INTEGER NOT NULL REFERENCES disclosures(id) ON DELETE CASCADE,
    old_status TEXT,
    new_status TEXT NOT NULL,
    note TEXT,
    changed_by INTEGER REFERENCES users(id),
    changed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS remediation (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    vulnerability_id INTEGER REFERENCES vulnerabilities(id) ON DELETE CASCADE,
    port_result_id INTEGER REFERENCES port_scan_results(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    assignee TEXT NOT NULL,
    priority TEXT NOT NULL DEFAULT 'Medium'
        CHECK (priority IN ('Low','Medium','High','Critical')),
    due_date TEXT,
    status TEXT NOT NULL DEFAULT 'Pending'
        CHECK (status IN ('Pending','In Progress','Completed')),
    notes TEXT,
    verified_at TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS audit_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    username TEXT,
    action TEXT NOT NULL,
    details TEXT,
    ip_address TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
"""


def get_db():
    """One SQLite connection per request."""
    if "db" not in g:
        g.db = sqlite3.connect(current_app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


def close_db(e=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    """Create all tables (safe to run repeatedly)."""
    os.makedirs(os.path.dirname(current_app.config["DATABASE"]), exist_ok=True)
    db = get_db()
    db.executescript(SCHEMA)
    db.commit()


def log_action(action, details=""):
    """Write an audit-log entry for the current user/request."""
    try:
        ip = request.remote_addr
    except RuntimeError:
        ip = None
    db = get_db()
    db.execute(
        "INSERT INTO audit_logs (user_id, username, action, details, ip_address) "
        "VALUES (?, ?, ?, ?, ?)",
        (session.get("user_id"), session.get("username", "system"), action, details, ip),
    )
    db.commit()


def seed_demo_data():
    """Optional demo data. Creates demo users, assets and one disclosure.

    It deliberately does NOT insert fake scan results or findings: run the real
    assessments from the web app so every result on screen is genuine.
    """
    db = get_db()
    if db.execute("SELECT 1 FROM users LIMIT 1").fetchone():
        print("Users already exist - skipping demo data.")
        return False

    db.execute(
        "INSERT INTO users (username, email, password_hash, role) VALUES (?,?,?,?)",
        ("admin", "admin@vulntrack.local", generate_password_hash("Admin@12345"), "admin"),
    )
    db.execute(
        "INSERT INTO users (username, email, password_hash, role) VALUES (?,?,?,?)",
        ("analyst", "analyst@vulntrack.local", generate_password_hash("Analyst@12345"), "user"),
    )
    db.execute(
        "INSERT INTO assets (name, target, asset_type, importance, description, authorized, created_by) "
        "VALUES (?,?,?,?,?,1,1)",
        ("Local Host (this PC)", "127.0.0.1", "host", "Medium",
         "Your own machine - safe target for demonstrating port checks.", ),
    )
    db.execute(
        "INSERT INTO assets (name, target, asset_type, importance, description, authorized, created_by) "
        "VALUES (?,?,?,?,?,1,1)",
        ("VulnTrack App (local)", "http://127.0.0.1:5000", "web", "High",
         "This application running locally - safe target for header checks."),
    )
    db.execute(
        "INSERT INTO disclosures (reference, reporter_name, reporter_email, asset_id, title, description, evidence_summary) "
        "VALUES (?,?,?,?,?,?,?)",
        ("VT-DEMO-0001", "Demo Reporter", "reporter@example.com", 2,
         "Demo: Missing security headers observed",
         "Sample report for demonstration purposes only.",
         "Response headers lacked CSP and HSTS."),
    )
    db.execute(
        "INSERT INTO disclosure_history (disclosure_id, new_status, note, changed_by) "
        "VALUES (1, 'Submitted', 'Demo record', 1)"
    )
    db.commit()
    return True
