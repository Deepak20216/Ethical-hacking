"""Central configuration. Values come from the .env file (never hard-code secrets)."""
import os
from dotenv import load_dotenv

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
load_dotenv(os.path.join(BASE_DIR, ".env"))


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY")
    if not SECRET_KEY:
        raise RuntimeError(
            "SECRET_KEY is not set. Copy .env.example to .env and set a SECRET_KEY."
        )

    DATABASE = os.path.join(BASE_DIR, "instance", "vulntrack.db")

    # Session / cookie hardening
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    PERMANENT_SESSION_LIFETIME = 60 * 60 * 2  # 2 hours

    # Safety limits for assessments (see modules/port_scanner.py)
    MAX_PORTS_PER_SCAN = 20      # hard cap on ports per scan
    PORT_SCAN_TIMEOUT = 1.0      # seconds per TCP connect attempt
    HTTP_CHECK_TIMEOUT = 8       # seconds for header checks
